def main():
    print('Hi from drone_project.')


if __name__ == '__main__':
    main()
